
function addProduct() {
    let form = document.getElementById("myform");
    let name = form.name.value;
    let price = form.price.value;
    let image= form.img.value;

    var obj = {
        name,
        price,
        image
    }

    let arr;
    localStorage.getItem("addItem");
    if (arr == null) {
        arr = [];
    }
    else {
        arr = JSON.parse(localStorage.getItem("addItem"));
    }
    arr.push(obj);
    localStorage.setItem("addItem", JSON.stringify(arr));
}
let data_item = document.getElementById("conatainer");

function showItem(el) {
    let div = document.createElement("div");

    let p_name = document.createElement("p")
    p_name.textContent = el.name;

    let p_price = document.createElement("p");
    p_price.innerHTML = el.price;

    let img = document.createElement("img");
    img.src = el.image;

    div.append(p_name, p_price, img);

    data_item.append(div);
}

function callItem() {
    let data = JSON.parse(localStorage.getItem("addItem"));

    data.forEach(function (el) {
        showItem(el);
    })
}
callItem();